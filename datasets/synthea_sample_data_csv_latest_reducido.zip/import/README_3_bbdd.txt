Criterio aplicado
=================
- Se ha mantenido intacto patients.csv.
- Se han reordenado solo los CSV con columna PATIENT, siguiendo exactamente el orden de aparición de los pacientes en patients.csv.
- Dentro de cada paciente, se ha conservado el orden original de sus filas.
- Después se han calculado los cortes correspondientes a 3 bloques de 39 pacientes: pacientes 1-39, 40-78 y 79-117.
- Los valores de SKIP y LIMIT del resumen cuentan solo filas de datos, no la cabecera.

Nota sobre organizations.csv y providers.csv
============================================
Estos ficheros no tienen columna PATIENT. Por tanto, no pueden repartirse homogéneamente por pacientes usando solo un corte con SKIP/LIMIT.
La opción más segura es importarlos completos en las tres bases de datos, salvo que quieras definir otro criterio de partición.